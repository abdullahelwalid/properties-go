package handler

import (
	"golang-test/models"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type PropertiesHandler struct {
	DB *gorm.DB
}

func (p *PropertiesHandler) GetProperties(c *gin.Context) {
	var properties []models.Property
	p.DB.Model(models.Property{}).Preload(clause.Associations).Find(&properties)
	c.JSON(http.StatusOK, gin.H{"properties": properties})
}

func (p *PropertiesHandler) CreateProperty(c *gin.Context) {
	var property models.Property
	if err := c.BindJSON(&property); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}
	p.DB.Create(property)
	c.JSON(http.StatusCreated, gin.H{"message": "property created successfully"})
}
