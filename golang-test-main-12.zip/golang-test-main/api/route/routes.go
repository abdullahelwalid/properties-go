package route

import (
	"golang-test/api/handler"
	"golang-test/utils"

	"github.com/gin-gonic/gin"
)

func SetupRouter(userHandler *handler.UserHandler, authHandler *handler.AuthHandler, roleHandler *handler.RoleHandler, propertiesHandler *handler.PropertiesHandler, categoryHandler *handler.PropertyCategoryHandler, propertyTypesHandler *handler.PropertyTypeHandler) *gin.Engine {
	router := gin.Default()
	router.POST("/login", authHandler.Login)
	router.POST("/users", userHandler.CreateUser)
	authorizedRouter := router.Group("/")
	authorizedRouter.Use(utils.AuthMiddleware())
	authorizedRouter.GET("/users", userHandler.GetAllUsers)
	authorizedRouter.POST("/roles", roleHandler.CreateRole)
	authorizedRouter.GET("/properties", propertiesHandler.GetProperties)
	authorizedRouter.POST("/properties", propertiesHandler.CreateProperty)
	authorizedRouter.GET("/categories", categoryHandler.GetCategories)
	authorizedRouter.POST("/categories", categoryHandler.CreateCategory)
	authorizedRouter.GET("/types", propertyTypesHandler.GetTypes)
	authorizedRouter.POST("/types", propertyTypesHandler.CreateType)
	return router
}
