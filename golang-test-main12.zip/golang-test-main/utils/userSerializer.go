package utils

import (
	"golang-test/models"
	"sync"
)

type Pool struct {
	Concurrency int
	TaskChan    chan models.User
	ResultsChan chan map[string]interface{}
	Wg          sync.WaitGroup
	Mu          sync.Mutex
}

func (p *Pool) Worker() {
	for task := range p.TaskChan {
		user := task.Serialize()
		p.Mu.Lock()
		p.ResultsChan <- *user
		p.Mu.Unlock()
		p.Wg.Done()
	}
}

func (p *Pool) Run(users []models.User) []map[string]interface{} {
	p.Wg.Add(len(users))
	p.ResultsChan = make(chan map[string]interface{}, len(users))
	p.TaskChan = make(chan models.User, len(users))
	for i := 0; i < p.Concurrency; i++ {
		go p.Worker()
	}
	for _, user := range users {
		p.TaskChan <- user
	}
	close(p.TaskChan)
	var serializedUsers []map[string]interface{}
	for serializedUser := range p.ResultsChan {
		serializedUsers = append(serializedUsers, serializedUser)
		<-p.ResultsChan
	}
	close(p.ResultsChan)
	p.Wg.Wait()
	return serializedUsers
}
