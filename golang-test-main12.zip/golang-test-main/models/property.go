package models

import "gorm.io/gorm"

type Property struct {
	gorm.Model
	ID                 uint             `gorm:"primarykey"`
	Name               string           `json:"name"`
	Description        string           `json:"description"`
	Price              float32          `json:"price"`
	ImageURL           string           `json:"imageURL"`
	PropertyTypeID     uint             `json:"propertyTypeId"`
	PropertyType       PropertyType     `json:"propertyType"`
	PropertyCategoryID uint             `json:"propertyCategoryId"`
	PropertyCategory   PropertyCategory `json:"propertyCategory"`
}
