package route

import (
	"golang-test/api/handler"
	"golang-test/utils"

	"github.com/gin-gonic/gin"
)

func SetupRouter(userHandler *handler.UserHandler, authHandler *handler.AuthHandler, roleHandler *handler.RoleHandler) *gin.Engine {
	router := gin.Default()
	router.POST("/login", authHandler.Login)
	router.POST("/users", userHandler.CreateUser)
	authorizedRouter := router.Group("/")
	authorizedRouter.Use(utils.AuthMiddleware())
	authorizedRouter.GET("/users", userHandler.GetAllUsers)
	authorizedRouter.POST("/roles", roleHandler.CreateRole)
	return router
}
